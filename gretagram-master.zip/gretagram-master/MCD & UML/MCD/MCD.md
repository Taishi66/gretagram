# MCD

![MCD](MCD GRAM.png)
