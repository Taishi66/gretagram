<div class="container" <div class="inbox">
    <div>
        <div>
            Liste destinataires
        </div>
        <ul class="">
            <li>jc</li>
            <li>nadia</li>
            <li>jp</li>
            <li>guillaume</li>
        </ul>
    </div>
    <div>
        Discussion en cours
    </div>
</div>