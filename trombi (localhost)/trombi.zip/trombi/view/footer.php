<footer class="footer">
    <div class="container"> 
            <div class="col-md-12">
                Footer
            </div> 
    </div>
</footer>
</body>
</html>