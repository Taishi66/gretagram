<h1>Profil de <?php echo strtoupper($profil['nom']); ?></h1>
<div class="row container-fluid">
  <!-- affiche les informations du profil -->
    <div class="col-4">
        <img src="<?php echo $profil['image']; ?>" class="figure-img img-fluid rounded"><br>
        <b> 
        <?php echo  $profil['prenom']; ?> 
        <?php echo  strtoupper($profil['nom']); ?>
        </b>
        <br> <?php echo  $profil['infos']; ?>
        <br> <?php echo  $profil['email']; ?>
    </div>
    <!-- affiche les categories et le contenus du profil -->
    <div class="col-8">
        <?php
        // je declare la variable $cat vide
        $cat = "";
        foreach ($profilConCat as $data) {
            // je fait un cotrole si $cat et different de $data['id_categorie'] j'affiche la categorie
            // si non je $afficheCat et vide
            // $afficheCat = ($cat != $data['id_categorie']) ? "<h3>" .  $data['cat'] . "</h3>" : "";
            if ($cat != $data['id_categorie']) {
                $afficheCat = "<h3 >" .  $data['cat'] . "</h3>";
            } else {
                $afficheCat = "";
            }
            echo "         
            " . $afficheCat . "        
            <b >  " .  $data['nom'] . " </b>
            <p > " . $data['description'] . "</p>
            ";
            // j'alimente la variabe $cat par l'id de la categorie
            $cat = $data['id_categorie'];
        } ?>

    </div>