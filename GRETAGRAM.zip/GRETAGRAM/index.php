<?php
require_once './vendor/autoload.php';
 
// application code

use api\Instagram;

require "Instagram.php";
testestest